import React from 'react'
import { Link } from 'react-router-dom'
import Bargraph from './Bargraph'
import './Graph.css'

function Graphs() {
    return (
        <div className='container'>
            <Bargraph />
        </div>
    )
}

export default Graphs