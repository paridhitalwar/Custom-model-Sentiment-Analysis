import React from "react";
//import ReactDOM from 'react-dom/client';
import App from "./App";
import { render } from "react-dom";
const root = document.getElementById("root");
render(<App />, root);
