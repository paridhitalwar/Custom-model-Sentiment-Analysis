import React, { useState } from "react";
import "./Bargraph.css";
import "./Bubblechart.css";
import BubbleChart from "@weknow/react-bubble-chart-d3";
import { Chart as ChartJS, registerables } from "chart.js";
import Button from "./Buttons/Button";
import ChartDataLabels from "chartjs-plugin-datalabels";

ChartJS.register(ChartDataLabels);
ChartJS.register(...registerables);

const Bubblecharts = ({ datapos, dataneg }) => {
  const [option, setOption] = useState("1");
  return (
    <>
      <div className="option-wrap">
        <div className="button-wrap">
          <Button
            buttonStyle={`${
              option === "1" ? "btn--primary--solid" : "btn--primary--outline"
            }`}
            onClick={(e) => setOption("1")}
          >
            Areas of Excellence
          </Button>
        </div>
        <div className="button-wrap">
          <Button
            buttonStyle={`${
              option === "2" ? "btn--primary--solid" : "btn--primary--outline"
            }`}
            onClick={(e) => setOption("2")}
          >
            Areas of Improvement
          </Button>
        </div>
      </div>
      <div className="content-wrap">
        {option === "1" && (
          <div className="container">
            <div className="chart-containerb">
              <BubbleChart
                graph={{
                  zoom: 1,
                }}
                // ref={Bubbleref}
                width={600}
                height={600}
                padding={5} // optional value, number that set the padding between bubbles
                showLegend={false} // optional value, pass false to disable the legend.
                data={datapos}
                overflow={true}
              />
            </div>
          </div>
        )}
        {option === "2" && (
          <div className="container">
            <div className="chart-containerb">
              <BubbleChart
                graph={{
                  zoom: 0.9,
                }}
                // ref={Bubbleref}
                width={600}
                height={550}
                padding={5} // optional value, number that set the padding between bubbles
                showLegend={false} // optional value, pass false to disable the legend.
                data={dataneg}
                overflow={false}
              />
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default Bubblecharts;
