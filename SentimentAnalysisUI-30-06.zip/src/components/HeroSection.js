import React, { useState, useRef } from "react";
import "./HeroSection.css";
import Bubblecharts from "./Bubblecharts";
import Button from "./Buttons/Button";
import "./Bargraph.css";
import Papa from "papaparse";
import { Bar } from "react-chartjs-2";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ChartDataLabels from "chartjs-plugin-datalabels";
import { Chart as ChartJS, registerables } from "chart.js";
ChartJS.register(...registerables);
ChartJS.register(ChartDataLabels);

const HeroSection = () => {
  // states for file selection
  const [selectedFile, setSelectedFile] = useState();
  const [isFilePicked, setIsFilePicked] = useState(false);

  // refrences for charts
  const chartRefBar = useRef(null);

  // states for bar chart
  const [positiveData, setpositiveData] = useState([]);
  const [negativeData, setnegativeData] = useState([]);
  const [neutralData, setneutralData] = useState([]);

  // states for bubble chart
  const [positiveHashMap, setPositiveHashMap] = useState(new Map());
  const [negativeHashMap, setNegativeHashMap] = useState(new Map());
  const [mixedHashMap, setMixedHashMap] = useState(new Map());
  const [outputUrl, setOutputUrl] = useState("");
  const [positiveArray, setPositiveArray] = useState([]);
  const [negativeArray, setNegativeArray] = useState([]);
  const [sentimentData, setsentimentData] = useState([]);
  const [positiveAssessmentArray, setPositiveAssessmentArray] = useState([]);
  const [negativeAssessmentArray, setNegativeAssessmentArray] = useState([]);
  const [mixedAssessmentArray, setMixedAssessmentArray] = useState([]);
  const [targetBubble, setTargetBubble] = useState([]);
  const [mixedArray, setMixedArray] = useState([]);
  const [bubbleDataPos, setBubbleDataPos] = useState([]);
  const [bubbleDataNeg, setBubbleDataNeg] = useState([]);

  // states for response of fetch
  const [resString, setResString] = useState("");
  const [parsedCsv, setParsedCsv] = useState({});
  const [successfulReq, setSuccessfulReq] = useState(false);

  // state for barchart tooltip
  const [res, setRes] = useState();

  const colors = [
    "rgba(255, 26, 104, 0.7)",
    "rgba(54, 162, 235, 0.7)",
    "rgba(250, 185, 22, 0.7)",
    "rgba(114, 187, 222, 0.8)",
    "rgba(181, 134, 217, 0.8)",
    "rgba(242, 129, 59, 0.8)",
    "rgba(237, 46, 76, 0.8)",
    "rgba(255, 0, 255, 0.8)",
    "rgba(7, 81, 250, 0.8)",
    "rgba(255, 0, 40, 0.8)",
  ];

  const changeHandler = (event) => {
    setSelectedFile(event.target.files[0]);
    setIsFilePicked(true);
  };
  const data = {
    labels: ["Positive", "Negative", "Neutral"],
    datasets: [
      {
        label: "",
        data: [],
        backgroundColor: [
          "rgba(68, 235, 27, 0.7)",
          "rgba(250, 12, 36, 0.7)",
          "rgba(255, 206, 86, 0.7)",
        ],
        borderColor: [
          "rgba(68, 235, 27, 1)",
          "rgba(255, 59, 78, 1)",
          "rgba(255, 206, 86, 1)",
        ],
        borderWidth: 1,
      },
    ],
  };
  function updateChart() {
    if (successfulReq === false) {
      toast.info("Please select a file/Wait for data to arrive.", {
        autoClose: 1500,
      });
    } else {
      //console.log("updatechart() called");
      var positive = positiveData.length,
        negative = negativeData.length,
        neutral = neutralData.length;
      //console.log("pos len ", positive);
      var array = [];
      array.push(positive);
      array.push(negative);
      array.push(neutral);
      let barChart = chartRefBar.current;
      barChart.data.datasets[0].data = array;
      barChart.update();
    }

    //console.log(barChart);
    // let bubbleChart = Bubbleref.current;
    // console.log(bubbleChart);
    // bubbleChart.props.data.map((obj, index) => ({
    //   ...obj,
    //   label: positiveArray[index],
    //   value: positiveArray[index],
    //   color: "#bc9172",
    // }));
    //console.log("bubble again ", bubbleChart.props.data);
    //bubbleChart.update();
  }
  const loadData = () => {
    if (!isFilePicked) {
      alert("Please select a file first");
    } else {
      const extension = selectedFile.type;
      if (extension.toLowerCase() !== "text/csv") {
        alert("Only csv files are allowed.");
      } else {
        //console.log("parsing");
        Papa.parse(document.getElementById("uploadfile").files[0], {
          header: true,
          complete: function (result) {
            //console.log("result is ", result);
            const sentimentdata = [];
            const positivedata = [];
            const negativedata = [];
            const neutraldata = [];
            const res = [[], [], []];
            const targetbubble = [];
            const positivehashmap = new Map();
            const negativehashmap = new Map();
            const mixedhashmap = new Map();
            const bubbledatapos = [];
            const bubbledataneg = [];
            const hash = new Map();
            const neghash = new Map();
            result.data.map((ele) => {
              sentimentdata.push(ele.sentiment);
              targetbubble.push(ele.target);
              if (ele.sentiment == "positive") {
                res[0].push(ele.assessment + " " + ele.target);
                positivedata.push(ele.positive);
                positivehashmap.has(ele.target)
                  ? positivehashmap.set(
                      ele.target,
                      positivehashmap.get(ele.target) + 1
                    )
                  : positivehashmap.set(ele.target, 1);
              } else if (ele.sentiment == "negative") {
                res[1].push(ele.assessment + " " + ele.target);
                negativedata.push(ele.negative);
                negativehashmap.has(ele.target)
                  ? negativehashmap.set(
                      ele.target,
                      negativehashmap.get(ele.target) + 1
                    )
                  : negativehashmap.set(ele.target, 1);
              } else if (ele.sentiment == "mixed") {
                res[2].push(ele.assessment + " " + ele.target);
                neutraldata.push(ele.neutral);
                mixedhashmap.has(ele.target)
                  ? mixedhashmap.set(
                      ele.target,
                      mixedhashmap.get(ele.target) + 1
                    )
                  : mixedhashmap.set(ele.target, 1);
              }
              if (ele.sentiment == "positive") {
                var ok = false;
                if (
                  ele.target == "hospital" ||
                  ele.target == "experience" ||
                  ele.target == "Hospital" ||
                  ele.target == "hospital conditions" ||
                  ele.target == "Sonography department" ||
                  ele.target == "overcrowded" ||
                  ele.target == "Everyone"
                ) {
                  if (hash.has("Hospital")) {
                    hash.set("Hospital", hash.get("Hospital") + 1);
                  } else {
                    hash.set("Hospital", 1);
                  }
                  ok = true;
                }
                if (
                  ele.target == "ward" ||
                  ele.target == "facilities" ||
                  ele.target == "place" ||
                  ele.target == "Place" ||
                  ele.target == "Parking area" ||
                  ele.target == "ambulance service" ||
                  ele.target == "surgery" ||
                  ele.target == "ventilation"
                ) {
                  ok = true;
                  if (hash.has("Infastructure")) {
                    hash.set("Infastructure", hash.get("Infastructure") + 1);
                  } else {
                    hash.set("Infastructure", 1);
                  }
                }
                if (ele.target == "manager" || ele.target == "management") {
                  ok = true;
                  if (hash.has("Manager")) {
                    hash.set("Manager", hash.get("Manager") + 1);
                  } else {
                    hash.set("Manager", 1);
                  }
                }
                if (
                  ele.target == "responce" ||
                  ele.target == "doctor's behaviour" ||
                  ele.target == "doctor" ||
                  ele.target == "doctors response" ||
                  ele.target == "Doctor" ||
                  ele.target == "Doctors"
                ) {
                  ok = true;
                  if (hash.has("Doctors")) {
                    hash.set("Doctors", hash.get("Doctors") + 1);
                  } else {
                    hash.set("Doctors", 1);
                  }
                }
                if (
                  ele.target == "cleanliness" ||
                  ele.target == "ward" ||
                  ele.target == "Cleanliness"
                ) {
                  ok = true;
                  if (hash.has("Cleanliness")) {
                    hash.set("Cleanliness", hash.get("Cleanliness") + 1);
                  } else {
                    hash.set("Cleanliness", 1);
                  }
                }
                if (
                  ele.target == "machines" ||
                  ele.target == "X-ray machines"
                ) {
                  ok = true;
                  if (hash.has("Machines")) {
                    hash.set("Machines", hash.get("Machines") + 1);
                  } else {
                    hash.set("Machines", 1);
                  }
                }
                if (
                  ele.target == "food" ||
                  ele.target == "Tea" ||
                  ele.target == "Canteen-food"
                ) {
                  ok = true;
                  if (hash.has("Food")) {
                    hash.set("Food", hash.get("Food") + 1);
                  } else {
                    hash.set("Food", 1);
                  }
                }
                if (
                  ele.target == "behaviour" ||
                  ele.target == "technician" ||
                  ele.target == "Technician" ||
                  ele.target == "nurse" ||
                  ele.target == "Everyone" ||
                  ele.target == "nurses" ||
                  ele.target == "staff" ||
                  ele.tartget == "nurses"
                ) {
                  ok = true;
                  if (hash.has("Staff")) {
                    hash.set("Staff", hash.get("Staff") + 1);
                  } else {
                    hash.set("Staff", 1);
                  }
                }
                if (ele.target == "bill" || ele.target == "accommodation") {
                  ok = true;
                  if (hash.has("Bill Cost")) {
                    hash.set("Bill Cost", hash.get("Bill Cost") + 1);
                  } else {
                    hash.set("Bill Cost", 1);
                  }
                }
                if (
                  ele.target == "medicines" ||
                  ele.target == "medicine" ||
                  ele.target == "Prescribed-medicines"
                ) {
                  ok = true;
                  if (hash.has("Pharmacy")) {
                    hash.set("Pharmacy", hash.get("Pharmacy") + 1);
                  } else {
                    hash.set("Pharmacy", 1);
                  }
                }
                if (ele.target == "OPD") {
                  ok = true;
                  if (hash.has("OPD")) {
                    hash.set("OPD", hash.get("OPD") + 1);
                  } else {
                    hash.set("OPD", 1);
                  }
                }
                if (ok == false) {
                  if (hash.has(ele.target)) {
                    hash.set(ele.target, hash.get(ele.target) + 1);
                  } else {
                    hash.set(ele.target, 1);
                  }
                }
              }
              if (ele.sentiment == "negative") {
                var ok = false;
                if (
                  ele.target == "hospital" ||
                  ele.target == "experience" ||
                  ele.target == "Hospital" ||
                  ele.target == "hospital conditions" ||
                  ele.target == "Sonography department" ||
                  ele.target == "overcrowded" ||
                  ele.target == "Everyone"
                ) {
                  if (neghash.has("Hospital")) {
                    neghash.set("Hospital", neghash.get("Hospital") + 1);
                  } else {
                    neghash.set("Hospital", 1);
                  }
                  ok = true;
                }
                if (
                  ele.target == "ward" ||
                  ele.target == "facilities" ||
                  ele.target == "place" ||
                  ele.target == "Place" ||
                  ele.target == "Parking area" ||
                  ele.target == "ambulance service" ||
                  ele.target == "surgery" ||
                  ele.target == "ventilation"
                ) {
                  ok = true;
                  if (neghash.has("Infastructure")) {
                    neghash.set(
                      "Infastructure",
                      neghash.get("Infastructure") + 1
                    );
                  } else {
                    neghash.set("Infastructure", 1);
                  }
                }
                if (ele.target == "manager" || ele.target == "management") {
                  ok = true;
                  if (neghash.has("Manager")) {
                    neghash.set("Manager", neghash.get("Manager") + 1);
                  } else {
                    neghash.set("Manager", 1);
                  }
                }
                if (
                  ele.target == "responce" ||
                  ele.target == "doctor's behaviour" ||
                  ele.target == "doctor" ||
                  ele.target == "doctors response" ||
                  ele.target == "Doctor" ||
                  ele.target == "Doctors"
                ) {
                  ok = true;
                  if (neghash.has("Doctors")) {
                    neghash.set("Doctors", neghash.get("Doctors") + 1);
                  } else {
                    neghash.set("Doctors", 1);
                  }
                }
                if (
                  ele.target == "cleanliness" ||
                  ele.target == "ward" ||
                  ele.target == "Cleanliness"
                ) {
                  ok = true;
                  if (neghash.has("Cleanliness")) {
                    neghash.set("Cleanliness", neghash.get("Cleanliness") + 1);
                  } else {
                    neghash.set("Cleanliness", 1);
                  }
                }
                if (
                  ele.target == "machines" ||
                  ele.target == "X-ray machines"
                ) {
                  ok = true;
                  if (neghash.has("Machines")) {
                    neghash.set("Machines", neghash.get("Machines") + 1);
                  } else {
                    neghash.set("Machines", 1);
                  }
                }
                if (
                  ele.target == "food" ||
                  ele.target == "Tea" ||
                  ele.target == "Canteen-food"
                ) {
                  ok = true;
                  if (neghash.has("Food")) {
                    neghash.set("Food", neghash.get("Food") + 1);
                  } else {
                    neghash.set("Food", 1);
                  }
                }
                if (
                  ele.target == "behaviour" ||
                  ele.target == "technician" ||
                  ele.target == "Technician" ||
                  ele.target == "nurse" ||
                  ele.target == "Everyone" ||
                  ele.target == "nurses" ||
                  ele.target == "staff" ||
                  ele.tartget == "nurses"
                ) {
                  ok = true;
                  if (neghash.has("Staff")) {
                    neghash.set("Staff", neghash.get("Staff") + 1);
                  } else {
                    neghash.set("Staff", 1);
                  }
                }
                if (ele.target == "bill" || ele.target == "accommodation") {
                  ok = true;
                  if (neghash.has("Bill Cost")) {
                    neghash.set("Bill Cost", neghash.get("Bill Cost") + 1);
                  } else {
                    neghash.set("Bill Cost", 1);
                  }
                }
                if (
                  ele.target == "medicines" ||
                  ele.target == "medicine" ||
                  ele.target == "Prescribed-medicines"
                ) {
                  ok = true;
                  if (neghash.has("Pharmacy")) {
                    neghash.set("Pharmacy", neghash.get("Pharmacy") + 1);
                  } else {
                    neghash.set("Pharmacy", 1);
                  }
                }
                if (ele.target == "OPD") {
                  ok = true;
                  if (neghash.has("OPD")) {
                    neghash.set("OPD", neghash.get("OPD") + 1);
                  } else {
                    neghash.set("OPD", 1);
                  }
                }
                if (ok == false) {
                  if (neghash.has(ele.target)) {
                    neghash.set(ele.target, neghash.get(ele.target) + 1);
                  } else {
                    neghash.set(ele.target, 1);
                  }
                }
              }
            });
            const positivearray = Array.from(hash.values());
            const negativearray = Array.from(neghash.values());
            const mixedarray = Array.from(mixedhashmap.values());
            const positiveassesementarray = Array.from(hash.keys());
            const negativeassesementarray = Array.from(neghash.keys());
            const mixedassessmentarray = Array.from(mixedhashmap.keys());
            setTargetBubble(targetbubble);
            setPositiveArray(positivearray);
            setNegativeArray(negativearray);
            setMixedArray(mixedarray);
            setPositiveAssessmentArray(positiveassesementarray);
            setNegativeAssessmentArray(negativeassesementarray);
            setMixedAssessmentArray(mixedassessmentarray);
            setRes(res);
            setPositiveHashMap(positivehashmap);
            setNegativeHashMap(negativehashmap);
            setMixedHashMap(mixedhashmap);
            setsentimentData(sentimentdata);
            setpositiveData(positivedata);
            setnegativeData(negativedata);
            setneutralData(neutraldata);
            positivearray.map((value, index) => {
              bubbledatapos.push({
                label: positiveassesementarray[index],
                value: value,
                color: colors[Math.floor(Math.random() * 10)],
              });
            });
            setBubbleDataPos(bubbledatapos);
            negativearray.map((value, index) => {
              bubbledataneg.push({
                label: negativeassesementarray[index],
                value: value,
                color: colors[Math.floor(Math.random() * 10)],
              });
            });
            setBubbleDataNeg(bubbledataneg);
          },
        });
      }
    }
  };
  function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }
  const handleSubmission = () => {
    if (!isFilePicked) {
      toast.info("Please pick a file first!", { autoClose: 1500 });
    } else {
      const extension = selectedFile.type;
      var url;
      if (extension === "text/plain") {
        url =
          "https://omms-interns-sa.azurewebsites.net/fileHandle/sendFile/txt";
      } else if (extension === "text/csv") {
        url =
          "https://omms-interns-sa.azurewebsites.net/fileHandle/sendFile/csv";
      } else {
        toast.info("File type is not valid.", { autoClose: 1500 });
        return;
      }
      toast.success("Submitting the file!", { autoClose: 1500 });
      const formData = new FormData();
      formData.append("file", selectedFile);
      fetch(url, {
        method: "POST",
        body: formData,
        // mode: "no-cors",
      })
        .then((response) => {
          const reader = response.body.getReader();
          return new ReadableStream({
            start(controller) {
              return pump();
              function pump() {
                return reader.read().then(({ done, value }) => {
                  // When no more data needs to be consumed, close the stream
                  if (done) {
                    controller.close();
                    return;
                  }
                  // Enqueue the next data chunk into our target stream
                  controller.enqueue(value);
                  return pump();
                });
              }
            },
          });
        })
        .then((stream) => new Response(stream))
        // Create an object URL for the response
        .then((response) => response.text())
        .then((response) => {
          if (response[1] === "s") {
            setSuccessfulReq(true);
          } else {
            return Promise.reject();
          }
          //console.log("res is ", response[1]);
          return response;
        })
        .then((response) => {
          setResString(response);
          return response;
        })
        .then((response) => {
          //console.log("res is, ", response);
          // var newres = response.substring(0, response.length - 1);
          var CsvString = Papa.parse(response, { header: true });
          setParsedCsv(CsvString);
          // console.log("CsvString is ", CsvString);
          return CsvString;
        })
        .then((CsvString) => {
          const sentimentdata = [];
          const positivedata = [];
          const negativedata = [];
          const neutraldata = [];
          const res = [[], [], []];
          const targetbubble = [];
          const positivehashmap = new Map();
          const negativehashmap = new Map();
          const mixedhashmap = new Map();
          const bubbledatapos = [];
          const bubbledataneg = [];
          const hash = new Map();
          const neghash = new Map();
          CsvString.data.map((ele) => {
            sentimentdata.push(ele.sentiment);
            targetbubble.push(ele.target);
            if (ele.sentiment === "positive") {
              res[0].push(ele.assessment + " " + ele.target);
              positivedata.push(ele.positive);
              positivehashmap.has(ele.target)
                ? positivehashmap.set(
                    ele.target,
                    positivehashmap.get(ele.target) + 1
                  )
                : positivehashmap.set(ele.target, 1);
            } else if (ele.sentiment === "negative") {
              res[1].push(ele.assessment + " " + ele.target);
              negativedata.push(ele.negative);
              negativehashmap.has(ele.target)
                ? negativehashmap.set(
                    ele.target,
                    negativehashmap.get(ele.target) + 1
                  )
                : negativehashmap.set(ele.target, 1);
            } else if (ele.sentiment === "mixed") {
              res[2].push(ele.assessment + " " + ele.target);
              neutraldata.push(ele.neutral);
              mixedhashmap.has(ele.target)
                ? mixedhashmap.set(ele.target, mixedhashmap.get(ele.target) + 1)
                : mixedhashmap.set(ele.target, 1);
            }
            if (ele.sentiment === "positive") {
              var ok = false;
              if (
                ele.target === "hospital" ||
                ele.target === "Hospital" ||
                ele.target === "experience" ||
                ele.target === "Experience" ||
                ele.target === "hospital conditions" ||
                ele.target === "Hospital conditions" ||
                ele.target === "Hospital Conditions" ||
                ele.target === "Sonography Department" ||
                ele.target === "Sonography department" ||
                ele.target === "sonography department" ||
                ele.target === "overcrowded" ||
                ele.target === "Overcrowded" ||
                ele.target === "Everyone" ||
                ele.target === "everyone"
              ) {
                if (hash.has("Hospital")) {
                  hash.set("Hospital", hash.get("Hospital") + 1);
                } else {
                  hash.set("Hospital", 1);
                }
                ok = true;
              }
              if (
                ele.target === "ward" ||
                ele.target === "Ward" ||
                ele.target === "facilities" ||
                ele.target === "Facilities" ||
                ele.target === "place" ||
                ele.target === "Place" ||
                ele.target === "Parking area" ||
                ele.target === "parking area" ||
                ele.target === "Parking Area" ||
                ele.target === "ambulance service" ||
                ele.target === "Ambulance Service" ||
                ele.target === "Ambulance service" ||
                ele.target === "surgery" ||
                ele.target === "Surgery" ||
                ele.target === "ventilation" ||
                ele.target === "Ventilation"
              ) {
                ok = true;
                if (hash.has("Infastructure")) {
                  hash.set("Infastructure", hash.get("Infastructure") + 1);
                } else {
                  hash.set("Infastructure", 1);
                }
              }
              if (
                ele.target === "manager" ||
                ele.target === "Manager" ||
                ele.target === "management" ||
                ele.target === "Management"
              ) {
                ok = true;
                if (hash.has("Manager")) {
                  hash.set("Manager", hash.get("Manager") + 1);
                } else {
                  hash.set("Manager", 1);
                }
              }
              if (
                ele.target === "response" ||
                ele.target === "Response" ||
                ele.target === "doctor's behaviour" ||
                ele.target === "Doctor's behaviour" ||
                ele.target === "doctor" ||
                ele.target === "doctors response" ||
                ele.target === "Doctors response" ||
                ele.target === "doctor's response" ||
                ele.target === "Doctor's response" ||
                ele.target === "Doctor" ||
                ele.target === "doctors" ||
                ele.target === "Doctors"
              ) {
                ok = true;
                if (hash.has("Doctors")) {
                  hash.set("Doctors", hash.get("Doctors") + 1);
                } else {
                  hash.set("Doctors", 1);
                }
              }
              if (
                ele.target === "cleanliness" ||
                ele.target === "Cleanliness" ||
                ele.target === "Ward" ||
                ele.target === "ward"
              ) {
                ok = true;
                if (hash.has("Cleanliness")) {
                  hash.set("Cleanliness", hash.get("Cleanliness") + 1);
                } else {
                  hash.set("Cleanliness", 1);
                }
              }
              if (
                ele.target === "machines" ||
                ele.target === "Machines" ||
                ele.target === "X-ray machines" ||
                ele.target === "x-ray machines"
              ) {
                ok = true;
                if (hash.has("Machines")) {
                  hash.set("Machines", hash.get("Machines") + 1);
                } else {
                  hash.set("Machines", 1);
                }
              }
              if (
                ele.target === "food" ||
                ele.target === "Food" ||
                ele.target === "Tea" ||
                ele.target === "tea" ||
                ele.target === "Canteen-food" ||
                ele.target === "canteen-food" ||
                ele.target === "Canteen food" ||
                ele.target === "canteen food" ||
                ele.target === "Canteen Food"
              ) {
                ok = true;
                if (hash.has("Food")) {
                  hash.set("Food", hash.get("Food") + 1);
                } else {
                  hash.set("Food", 1);
                }
              }
              if (
                ele.target === "behaviour" ||
                ele.target === "Behaviour" ||
                ele.target === "technician" ||
                ele.target === "Technician" ||
                ele.target === "nurse" ||
                ele.target === "Nurse" ||
                ele.target === "Everyone" ||
                ele.target === "everyone" ||
                ele.target === "nurses" ||
                ele.target === "staff" ||
                ele.target === "Staff" ||
                ele.tartget === "Nurses"
              ) {
                ok = true;
                if (hash.has("Staff")) {
                  hash.set("Staff", hash.get("Staff") + 1);
                } else {
                  hash.set("Staff", 1);
                }
              }
              if (
                ele.target === "bill" ||
                ele.target === "Bill" ||
                ele.target === "Accommodation" ||
                ele.target === "accommodation"
              ) {
                ok = true;
                if (hash.has("Bill Cost")) {
                  hash.set("Bill Cost", hash.get("Bill Cost") + 1);
                } else {
                  hash.set("Bill Cost", 1);
                }
              }
              if (
                ele.target === "medicines" ||
                ele.target === "Medicines" ||
                ele.target === "medicine" ||
                ele.target === "Medicine" ||
                ele.target === "Prescribed-medicines" ||
                ele.target === "prescribed-medicines"
              ) {
                ok = true;
                if (hash.has("Pharmacy")) {
                  hash.set("Pharmacy", hash.get("Pharmacy") + 1);
                } else {
                  hash.set("Pharmacy", 1);
                }
              }
              if (ele.target === "OPD" || ele.target === "opd") {
                ok = true;
                if (hash.has("OPD")) {
                  hash.set("OPD", hash.get("OPD") + 1);
                } else {
                  hash.set("OPD", 1);
                }
              }
              if (ok === false) {
                if (hash.has(ele.target)) {
                  hash.set(ele.target, hash.get(ele.target) + 1);
                } else {
                  hash.set(ele.target, 1);
                }
              }
            }
            if (ele.sentiment === "negative") {
              var ok = false;
              if (
                ele.target === "hospital" ||
                ele.target === "experience" ||
                ele.target === "Experience" ||
                ele.target === "Hospital" ||
                ele.target === "hospital conditions" ||
                ele.target === "Hospital conditions" ||
                ele.target === "Sonography department" ||
                ele.target === "sonography department" ||
                ele.target === "overcrowded" ||
                ele.target === "Overcrowded" ||
                ele.target === "Everyone" ||
                ele.target === "everyone"
              ) {
                if (neghash.has("Hospital")) {
                  neghash.set("Hospital", neghash.get("Hospital") + 1);
                } else {
                  neghash.set("Hospital", 1);
                }
                ok = true;
              }
              if (
                ele.target === "ward" ||
                ele.target === "Ward" ||
                ele.target === "facilities" ||
                ele.target === "Facilities" ||
                ele.target === "place" ||
                ele.target === "Place" ||
                ele.target === "Parking area" ||
                ele.target === "parking area" ||
                ele.target === "ambulance service" ||
                ele.target === "Ambulance service" ||
                ele.target === "surgery" ||
                ele.target === "Surgery" ||
                ele.target === "Ventilation" ||
                ele.target === "ventilation"
              ) {
                ok = true;
                if (neghash.has("Infastructure")) {
                  neghash.set(
                    "Infastructure",
                    neghash.get("Infastructure") + 1
                  );
                } else {
                  neghash.set("Infastructure", 1);
                }
              }
              if (
                ele.target === "manager" ||
                ele.target === "Manager" ||
                ele.target === "Management" ||
                ele.target === "management"
              ) {
                ok = true;
                if (neghash.has("Manager")) {
                  neghash.set("Manager", neghash.get("Manager") + 1);
                } else {
                  neghash.set("Manager", 1);
                }
              }
              if (
                ele.target === "response" ||
                ele.target === "Response" ||
                ele.target === "Doctor's behaviour" ||
                ele.target === "doctor's behaviour" ||
                ele.target === "doctor" ||
                ele.target === "Doctors response" ||
                ele.target === "doctors response" ||
                ele.target === "doctor's response" ||
                ele.target === "Doctor's response" ||
                ele.target === "Doctor" ||
                ele.target === "doctors" ||
                ele.target === "Doctors"
              ) {
                ok = true;
                if (neghash.has("Doctors")) {
                  neghash.set("Doctors", neghash.get("Doctors") + 1);
                } else {
                  neghash.set("Doctors", 1);
                }
              }
              if (
                ele.target === "cleanliness" ||
                ele.target === "Cleanliness" ||
                ele.target === "ward" ||
                ele.target === "Ward"
              ) {
                ok = true;
                if (neghash.has("Cleanliness")) {
                  neghash.set("Cleanliness", neghash.get("Cleanliness") + 1);
                } else {
                  neghash.set("Cleanliness", 1);
                }
              }
              if (
                ele.target === "machines" ||
                ele.target === "Machines" ||
                ele.target === "X-ray machines" ||
                ele.target === "x-ray machines"
              ) {
                ok = true;
                if (neghash.has("Machines")) {
                  neghash.set("Machines", neghash.get("Machines") + 1);
                } else {
                  neghash.set("Machines", 1);
                }
              }
              if (
                ele.target === "food" ||
                ele.target === "Food" ||
                ele.target === "Tea" ||
                ele.target === "tea" ||
                ele.target === "Canteen-food" ||
                ele.target === "canteen-food" ||
                ele.target === "Canteen food" ||
                ele.target === "canteen food" ||
                ele.target === "Canteen Food"
              ) {
                ok = true;
                if (neghash.has("Food")) {
                  neghash.set("Food", neghash.get("Food") + 1);
                } else {
                  neghash.set("Food", 1);
                }
              }
              if (
                ele.target === "behaviour" ||
                ele.target === "Behaviour" ||
                ele.target === "technician" ||
                ele.target === "Technician" ||
                ele.target === "nurse" ||
                ele.target === "Nurse" ||
                ele.target === "Everyone" ||
                ele.target === "everyone" ||
                ele.target === "nurses" ||
                ele.target === "Nurses" ||
                ele.target === "staff" ||
                ele.target === "Staff" ||
                ele.target === "nurses" ||
                ele.target === "Nurses"
              ) {
                ok = true;
                if (neghash.has("Staff")) {
                  neghash.set("Staff", neghash.get("Staff") + 1);
                } else {
                  neghash.set("Staff", 1);
                }
              }
              if (
                ele.target === "bill" ||
                ele.target === "Bill" ||
                ele.target === "accommodation" ||
                ele.target === "Accommodation"
              ) {
                ok = true;
                if (neghash.has("Bill Cost")) {
                  neghash.set("Bill Cost", neghash.get("Bill Cost") + 1);
                } else {
                  neghash.set("Bill Cost", 1);
                }
              }
              if (
                ele.target === "medicines" ||
                ele.target === "Medicines" ||
                ele.target === "medicine" ||
                ele.target === "Medicine" ||
                ele.target === "prescribed-medicines" ||
                ele.target === "prescribed medicines" ||
                ele.target === "prescribed Medicines" ||
                ele.target === "Prescribed-medicines"
              ) {
                ok = true;
                if (neghash.has("Pharmacy")) {
                  neghash.set("Pharmacy", neghash.get("Pharmacy") + 1);
                } else {
                  neghash.set("Pharmacy", 1);
                }
              }
              if (ele.target === "OPD" || ele.target === "opd") {
                ok = true;
                if (neghash.has("OPD")) {
                  neghash.set("OPD", neghash.get("OPD") + 1);
                } else {
                  neghash.set("OPD", 1);
                }
              }
              if (ok === false) {
                if (neghash.has(ele.target)) {
                  neghash.set(ele.target, neghash.get(ele.target) + 1);
                } else {
                  neghash.set(ele.target, 1);
                }
              }
            }
          });
          const positivearray = Array.from(hash.values());
          const negativearray = Array.from(neghash.values());
          const mixedarray = Array.from(mixedhashmap.values());
          const positiveassesementarray = Array.from(hash.keys());
          const negativeassesementarray = Array.from(neghash.keys());
          setTargetBubble(targetbubble);
          setPositiveArray(positivearray);
          setNegativeArray(negativearray);
          setMixedArray(mixedarray);
          setRes(res);
          setsentimentData(sentimentdata);
          setpositiveData(positivedata);
          setnegativeData(negativedata);
          setneutralData(neutraldata);
          positivearray.map((value, index) => {
            bubbledatapos.push({
              label: capitalizeFirstLetter(positiveassesementarray[index]),
              value: value,
              color: colors[Math.floor(Math.random() * 10)],
            });
          });
          setBubbleDataPos(bubbledatapos);
          negativearray.map((value, index) => {
            bubbledataneg.push({
              label: capitalizeFirstLetter(negativeassesementarray[index]),
              value: value,
              color: colors[Math.floor(Math.random() * 10)],
            });
          });
          setBubbleDataNeg(bubbledataneg);
          toast.success("File has been processed.", { autoClose: 1500 });
        })
        // .then((blob) => URL.createObjectURL(blob))
        // // Update image
        // .then((url) => console.log("url is ,", url))
        .catch((err) => {
          toast.error(
            "Some error occured. Please try submitting the file again.",
            { autoClose: 1500 }
          );
          console.error(err);
        });
    }
  };
  function camalize(mySentence) {
    return mySentence.replace(/(^\w{1})|(\s+\w{1})/g, (letter) =>
      letter.toUpperCase()
    );
  }
  const downloadFile = () => {
    if (resString !== "") {
      var dataStr = "data:csv;charset=utf-8," + encodeURIComponent(resString);
      var downloadAnchorNode = document.createElement("a");
      downloadAnchorNode.setAttribute("href", dataStr);
      downloadAnchorNode.setAttribute("download", "Output.csv");
      document.body.appendChild(downloadAnchorNode); // required for firefox
      downloadAnchorNode.click();
      downloadAnchorNode.remove();
    } else {
      toast.info("Please upload a file/Wait for data to arrive", {
        autoClose: 1500,
      });
    }
  };
  return (
    <div className="hero-container">
      <ToastContainer />
      <h1>Sentiment Analysis</h1>
      {/* {resString === "" ? null : resString} */}
      <p>
        Get detailed insights about what your customers say about your product.
      </p>
      <p>Upload a .csv or .txt file with the reviews to get started.</p>
      <div className="upload-container">
        <input
          type="file"
          className="upload-box"
          id="uploadfile"
          //accept=".csv"
          onChange={changeHandler}
          //onClick={loadData}
        />
        <div className="hero-btn">
          <Button
            onClick={() => {
              handleSubmission();
            }}
          >
            Submit
          </Button>
          <Button onClick={updateChart}>Visualize</Button>
          <Button onClick={downloadFile}>Download File</Button>
        </div>
        <h2>Overall Sentiment of Reviews</h2>
      </div>
      {/* Bar chart starts here */}
      <div className="container">
        <div className="chart-container">
          <Bar
            data={data}
            ref={chartRefBar}
            height="600px"
            width="800px"
            options={{
              maintainAspectRatio: false,
              plugins: {
                datalabels: false,
                legend: {
                  display: false,
                },
                tooltip: {
                  callbacks: {
                    afterBody: function (context) {
                      return res[context[0].dataIndex].map((ele) =>
                        camalize(ele)
                      );
                    },
                  },
                },
              },
              scales: {
                y: {
                  beginAtZero: true,
                },
              },
            }}
          />
        </div>
      </div>
      {/* Bar chart ends here */}
      <h2>Sentiment-wise Assessment of Targets</h2>

      {/* Bubble chart starts here */}

      <Bubblecharts dataneg={bubbleDataNeg} datapos={bubbleDataPos} />
      {/* <BubbleChart
        graph={{
          zoom: 1,
        }}
        ref={Bubbleref}
        width={800}
        height={1300}
        padding={5} // optional value, number that set the padding between bubbles
        showLegend={false} // optional value, pass false to disable the legend.
        //Custom bubble/legend click functions such as searching using the label, redirecting to other page
        // bubbleClickFunc={bubbleClick()}
        //legendClickFun={legendClick()}
        // data={[
        //   { label: "Kidney beans", value: 62.14, color: "#853238" },
        //   { label: "Ground beef", value: 57.49, color: "#bc9172" },
        //   { label: "Rice", value: 56.46, color: "#d9d2c5" },
        //   { label: "Capsicum", value: 44.48, color: "#aa5315" },
        //   { label: "Cream", value: 40.0, color: "#d7dbe2" },
        //   { label: "Olive oil", value: 38.49, color: "#dad95e" },
        //   { label: "Tomato paste", value: 33.02, color: "#b52323" },
        //   { label: "Tomato puree", value: 32.71, color: "#952a21" },
        //   { label: "Onion paste", value: 31.41, color: "#d9cda4" },
        //   { label: "Soy sauce", value: 31.07, color: "#1c1412" },
        //   { label: "Glucose", value: 20.8, color: "#e2dfe1" },
        //   { label: "Nutritional yeast", value: 19.57, color: "#c5b56d" },
        //   { label: "Lemon juice", value: 19.04, color: "#dad4bd" },
        //   { label: "Salt", value: 17.1, color: "#e5e6e5" },
        //   { label: "Shallots", value: 16.26, color: "#efcbbe" },
        //   { label: "Coriander leaves", value: 12.81, color: "#379218" },
        //   { label: "Cumin", value: 12.81, color: "#ba8f4e" },
        //   { label: "Coriander seed", value: 12.6, color: "#ad8e67" },
        //   { label: "Garlic powder", value: 12.39, color: "#d9c3a6" },
        //   { label: "Paprika", value: 12.16, color: "#c03123" },
        //   { label: "Fresh garlic", value: 11.93, color: "#e6e1bc" },
        //   { label: "Chili powder", value: 10.32, color: "#b12e2f" },
        //   { label: "Pepper", value: 8.14, color: "#72523f" },
        //   { label: "Celery seed", value: 8.09, color: "#a18d4c" },
        //   { label: "Cinnamon", value: 7.83, color: "#a85b2f" },
        //   { label: "Marjoram", value: 7.72, color: "#6e6e51" },
        // ]}
        data={bubbleData}
      /> */}
      {/* Bubble chart ends here */}
    </div>
  );
};

export default HeroSection;
